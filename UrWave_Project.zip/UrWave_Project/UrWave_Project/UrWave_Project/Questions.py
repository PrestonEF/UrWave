# Define a dictionary of mood options and corresponding playlists
mood_playlists = {
    "happy": ["Pop Hits", "Feel-Good Classics", "Upbeat Rock"],
    "relaxing": ["Acoustic Vibes", "Chill Out Mix", "Piano Instrumentals"],
    "energetic": ["High-Energy Workout", "Rock Anthems", "Dance Party Mix"],
    "cozy": ["Rainy Day Acoustics", "Indie Folk", "Coffee Shop Tunes"],
    "introspective": ["Deep Thoughts", "Acoustic Melancholy", "Indie Ballads"]
}

# Questionnaire
print("Welcome to the Mood-based Playlist Recommender!")
print("Answer a few questions to help us determine your mood.")

# Ask the user questions
mood = input("1. How are you feeling right now? (e.g., happy, sad, relaxed): ").lower()
activity = input("2. What kind of activities are you planning or currently engaged in? (e.g., workout, study, relax): ").lower()
weather = input("3. What's the weather like where you are? (e.g., sunny, rainy, snowy): ").lower()
color = input("4. Select a color that best represents your mood: ").lower()
music_preference = input("5. What type of music are you in the mood for? (e.g., pop, rock, acoustic): ").lower()

# Determine mood based on user responses
if mood in mood_playlists:
    recommended_playlists = mood_playlists[mood]
else:
    recommended_playlists = []

# Display recommended playlists
if recommended_playlists:
    print(f"\nRecommended Playlists for your mood ({mood}):")
    for playlist in recommended_playlists:
        print(f"- {playlist}")
else:
    print("Sorry, we couldn't determine a suitable playlist for your responses.")

# You can further customize the code to handle different user responses or add more mood options and playlists as needed.

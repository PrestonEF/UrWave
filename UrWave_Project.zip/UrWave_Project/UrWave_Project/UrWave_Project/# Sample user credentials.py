# Sample user credentials
user_credentials = {
    'deexfloyd': '123456',
}

# Function to validate user credentials
def login(username, password):
    if username in user_credentials and user_credentials[username] == password:
        return True
    else:
        return False

# Login page
def login_page():
    print("Welcome to the Music Recommender System")
    username = input("Username: ")
    password = input("Password: ")

    if login(username, password):
        print(f"Welcome, {username}!")
        return username
    else:
        print("Invalid username or password.")
        option = input("Options: (1) Forgot Username, (2) Forgot Password, (3) Contact Us\n")
        if option == '1':
            print("Forgot Username: Please contact support.")
        elif option == '2':
            print("Forgot Password: Please contact support.")
        elif option == '3':
            print("Contact Us: support@musicrecommender.com")
        else:
            print("Invalid option. Please contact support for assistance.")
        return None

# Main function
def main():
    user = login_page()
    if user:
        # If the user is successfully logged in, proceed to mood-based questions and playlist generation.
        mood = input("How are you feeling today? (e.g., happy, sad, calm): ")
        preference = input("What type of music are you in the mood for? (e.g., rock, pop, jazz): ")
        # Implement content-based filtering based on user mood and preference to generate a playlist.

if __name__ == "__main__":
    main()

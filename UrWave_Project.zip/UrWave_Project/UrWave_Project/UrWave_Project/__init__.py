"""
The flask application package.
"""

from flask import Flask
app = Flask(__name__)

import UrWave_Project.views
